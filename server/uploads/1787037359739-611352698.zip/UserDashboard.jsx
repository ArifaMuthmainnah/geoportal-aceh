import {
  useEffect,
  useMemo,
  useState,
} from 'react'

import {
  Link,
  useNavigate,
} from 'react-router'

import {
  getAllDatasets,
} from '../../api/datasetApi'

import {
  useAuth,
} from '../../context/AuthContext'


function UserDashboard() {

  const navigate = useNavigate()

  const {
    currentUser,
    logout,
  } = useAuth()


  // ===================================================
  // STATE
  // ===================================================

  const [datasets, setDatasets] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [search, setSearch] = useState('')


  // ===================================================
  // LOAD PUBLISHED DATASETS
  // ===================================================

  async function loadDatasets() {

    try {

      setLoading(true)
      setError('')

      const result = await getAllDatasets()

      setDatasets(Array.isArray(result) ? result : [])

    } catch (err) {

      console.error('Dataset error:', err)
      setError('Gagal memuat dataset.')
      setDatasets([])

    } finally {

      setLoading(false)

    }

  }

  useEffect(() => {
    loadDatasets()
  }, [])


  // ===================================================
  // HELPER - PUBLISHED CHECK
  // ===================================================

  function isDatasetPublished(dataset) {
    return (
      dataset.is_published === true ||
      dataset.published === true ||
      dataset.is_approved === true
    )
  }


  // ===================================================
  // PUBLISHED DATASETS ONLY
  // ===================================================

  const publishedDatasets = useMemo(
    () => datasets.filter(isDatasetPublished),
    [datasets]
  )


  // ===================================================
  // FILTER BY SEARCH
  // ===================================================

  const filteredDatasets = useMemo(() => {

    const keyword = search.trim().toLowerCase()

    if (!keyword) {
      return publishedDatasets
    }

    return publishedDatasets.filter((dataset) => {

      const title = String(dataset.title || '').toLowerCase()

      const abstract = String(
        dataset.abstract || dataset.description || ''
      ).toLowerCase()

      return title.includes(keyword) || abstract.includes(keyword)

    })

  }, [publishedDatasets, search])


  // ===================================================
  // STATISTICS
  // ===================================================

  const statistics = useMemo(() => {

    return [
      {
        label: 'Dataset Terpublikasi',
        value: publishedDatasets.length,
        icon: '✓',
      },
      {
        label: 'Total Dataset di Sistem',
        value: datasets.length,
        icon: '▦',
      },
    ]

  }, [datasets, publishedDatasets])


  // ===================================================
  // LOGOUT / REFRESH
  // ===================================================

  function handleLogout() {
    logout()
    navigate('/', { replace: true })
  }

  function handleRefresh() {
    loadDatasets()
  }


  // ===================================================
  // RENDER
  // ===================================================

  return (

    <main className="admin-page">

      <div className="admin-layout">


        {/* SIDEBAR */}

        <aside className="admin-sidebar">

          <div className="admin-sidebar-brand">
            <span>GEOPORTAL</span>
            <strong>ACEH</strong>
          </div>

          <div className="admin-sidebar-user">

            <div className="admin-user-avatar">
              {(currentUser?.username || 'U').charAt(0).toUpperCase()}
            </div>

            <div>
              <strong>{currentUser?.username || 'Pengguna'}</strong>
              <span>Pengguna</span>
            </div>

          </div>

          <nav className="admin-sidebar-nav">

            <button type="button" className="active">
              <span>▦</span>
              Dashboard
            </button>

            <Link to="/katalog" className="admin-sidebar-link">
              <span>◉</span>
              Lihat Katalog
            </Link>

            <Link to="/webgis" className="admin-sidebar-link">
              <span>⌖</span>
              WebGIS
            </Link>

          </nav>

          <button
            type="button"
            className="admin-sidebar-logout"
            onClick={handleLogout}
          >
            ← Logout
          </button>

        </aside>


        {/* MAIN */}

        <section className="admin-main">


          {/* HEADER */}

          <header className="admin-header">

            <div>
              <span className="section-eyebrow">PENGGUNA</span>
              <h1>Dashboard Saya</h1>
              <p>Lihat dataset yang sudah terpublikasi di Geoportal Aceh.</p>
            </div>

            <div className="admin-header-actions">

              <button
                type="button"
                className="admin-refresh-button"
                onClick={handleRefresh}
                disabled={loading}
              >
                ↻ {loading ? 'Memuat...' : 'Refresh'}
              </button>

              <Link to="/" className="admin-view-site">
                Lihat Website →
              </Link>

            </div>

          </header>


          {error && (
            <div className="admin-alert">
              {error}
            </div>
          )}


          {/* STATISTICS */}

          <section className="admin-stat-grid">

            {statistics.map((stat) => (

              <article className="admin-stat-card" key={stat.label}>

                <div className="admin-stat-icon">
                  {stat.icon}
                </div>

                <div>
                  <strong>{loading ? '...' : stat.value}</strong>
                  <span>{stat.label}</span>
                </div>

              </article>

            ))}

          </section>


          {/* DATASET LIST (READ ONLY) */}

          <section className="admin-panel">

            <div className="admin-panel-header">

              <div>
                <span className="section-eyebrow">KATALOG</span>
                <h2>Dataset Terpublikasi</h2>
              </div>

              <div className="admin-panel-actions">
                <Link to="/katalog" className="admin-secondary-button">
                  Buka Katalog
                </Link>
              </div>

            </div>

            <div className="admin-toolbar">
              <input
                type="search"
                placeholder="Cari dataset..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
            </div>

            {loading ? (

              <div className="admin-loading">
                Memuat dataset...
              </div>

            ) : filteredDatasets.length === 0 ? (

              <div className="admin-empty">
                <div style={{ fontSize: '36px', marginBottom: '10px' }}>◈</div>
                <strong>Belum ada dataset terpublikasi</strong>
                <p>Dataset yang dipublikasikan admin akan muncul di sini.</p>
              </div>

            ) : (

              <div className="admin-table-wrapper">

                <table className="admin-table">

                  <thead>
                    <tr>
                      <th>Dataset</th>
                      <th>Owner</th>
                      <th>Tanggal</th>
                      <th>Status</th>
                      <th>Aksi</th>
                    </tr>
                  </thead>

                  <tbody>

                    {filteredDatasets.slice(0, 50).map((dataset) => (

                      <tr key={dataset.pk}>

                        <td>
                          <strong>{dataset.title || 'Tanpa judul'}</strong>
                          <small>ID: {dataset.pk || '-'}</small>
                        </td>

                        <td>
                          {
                            dataset.owner?.username ||
                            dataset.owner?.first_name ||
                            dataset.owner?.name ||
                            '-'
                          }
                        </td>

                        <td>
                          {
                            dataset.date
                              ? new Date(dataset.date).toLocaleDateString('id-ID')
                              : '-'
                          }
                        </td>

                        <td>
                          <span className="admin-status published">
                            Published
                          </span>
                        </td>

                        <td>
                          <div className="admin-actions">
                            <Link
                              to={`/katalog/${dataset.pk}`}
                              className="admin-action-view"
                            >
                              Lihat
                            </Link>
                          </div>
                        </td>

                      </tr>

                    ))}

                  </tbody>

                </table>

              </div>

            )}

          </section>

        </section>

      </div>

    </main>

  )

}


export default UserDashboard
